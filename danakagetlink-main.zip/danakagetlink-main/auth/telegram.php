<?php
$telegram_id = "6219128386";
$id_bot = "6387358508:AAEhxDYeX0S6Hr7ErpdhOAYpxj2SvLZl0qY";
?>
